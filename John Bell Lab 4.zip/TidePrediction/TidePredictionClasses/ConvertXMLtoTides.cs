﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.Xml;
using System.IO;

namespace TidePredictionClasses
{
    public class ConvertXMLtoTides
    {
        public static List<Tides> ConvertTides(Stream file) {
            Tides tide = new Tides();
            List<Tides> tides = new List<Tides>();
            using (XmlReader reader = XmlReader.Create(file))
            {
                if (reader.IsStartElement())
                {
                    switch (reader.Name)
                    {
                        case "item":
                        tide = new Tides();
                            break;
                        case "date":
                            tide.Date = reader.Value.Trim();
                            tide.Index = Int32.Parse(reader.Value.Trim().Substring(5, 2));
                            break;
                        case "day":
                            tide.Day= reader.Value.Trim();
                            break;
                        case "time":
                            tide.Time = reader.Value.Trim();
                            break;
                        case "pred_in_ft":
                            tide.Feet= decimal.Parse(reader.Value.Trim());
                            break;
                        case "pred_in_cm":
                            tide.Cen = decimal.Parse(reader.Value.Trim());
                            break;
                        case "highlow":
                            tide.HL = reader.Value.Trim();
                            break;
                    }

                    }
                else
                {
                    if (reader.Name == "item") tides.Add(tide);
                }

            }
            tides.Sort((x, y) => x.Date.CompareTo(y.Date));
            return tides;
        }
    }
}