﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;



namespace TideDBClasses
{
    [Table("Tides")]
    public class TideDB
    {
        [PrimaryKey]
        public int ID { get; set; }
        public string Date { get; set; }
        public string Day { get; set; }
        public string Time { get; set; }
        public string Feet { get; set; }
        public string Locale { get; set; }
        public string Cen { get; set; }
        public string HL { get; set; }
        public string Index { get; set; }
    }
}
