﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TidePredictionClasses
{
    public class Tides
    {

        public string Date { get; set; }
        public string Day { get; set; }
        public string Time { get; set; }
        public string Feet { get; set; }
        public string Cen { get; set; }
        public string HL { get; set; }
        public int Index { get; set; }
    }

}
